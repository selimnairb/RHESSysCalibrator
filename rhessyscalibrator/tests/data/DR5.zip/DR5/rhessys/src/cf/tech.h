1973 10 1 1 print_daily_on
1977 11 1 1 redefine_strata
1980 9 30 1 print_daily_off

